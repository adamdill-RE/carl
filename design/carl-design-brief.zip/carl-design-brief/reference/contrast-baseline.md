# Contrast baseline — the palette as it stands today, measured

Computed with the WCAG 2.1 relative-luminance formula against the actual
foreground/background combinations the application renders. Reproduce it on
your own palette with `validate/contrast-check.html`, which runs the same
arithmetic.

Match or beat these.

| Foreground | Background | Where it renders | Ratio | Needs | |
|---|---|---|---:|---:|---|
| `--carl-text` #1f2420 | `--carl-bg` #f6f6f3 | Body text on the page | 14.57:1 | 4.5:1 | pass |
| `--carl-text` #1f2420 | `--carl-surface` #ffffff | Text on a card | 15.77:1 | 4.5:1 | pass |
| `--carl-text-muted` #5c635d | `--carl-surface` #ffffff | Help text, meta lines, citations | 6.18:1 | 4.5:1 | pass |
| `--carl-text-muted` #5c635d | `--carl-bg` #f6f6f3 | Muted text on the page | 5.71:1 | 4.5:1 | pass |
| `--carl-text-inverse` #ffffff | `--carl-primary` #2f6b3f | Topbar brand + primary button label | 6.37:1 | 4.5:1 | pass |
| `--carl-primary` #2f6b3f | `--carl-surface` #ffffff | `.btn-link`, timeline dot | 6.37:1 | 4.5:1 | pass |
| `--carl-primary-dark` #24522f | `--carl-surface` #ffffff | In-content links | 9.04:1 | 4.5:1 | pass |
| `--carl-primary-dark` #24522f | `--carl-primary-soft` #e6efe7 | `.badge` | 7.69:1 | 4.5:1 | pass |
| `--carl-text-muted` #5c635d | `--carl-surface-sunk` #eeeeea | `.badge-muted`, `.tier-skip` | 5.31:1 | 4.5:1 | pass |
| `--carl-warn` #8a6100 | `--carl-warn-soft` #fbf1d9 | `.tier-water`, `.notice-warn` | 4.93:1 | 4.5:1 | pass |
| `--carl-info` #1f4f77 | `--carl-info-soft` #e4eef7 | `.tier-likely`, `.notice-info` | 7.32:1 | 4.5:1 | pass |
| `--carl-ok` #2f6b3f | `--carl-ok-soft` #e6efe7 | `.notice-ok` | 5.42:1 | 4.5:1 | pass |
| `--carl-error` #a32020 | `--carl-error-soft` #fae7e7 | `.notice-error` | 6.34:1 | 4.5:1 | pass |
| `--carl-verified` #2f6b3f | `--carl-surface` #ffffff | Confidence: verified | 6.37:1 | 4.5:1 | pass |
| `--carl-approx` #8a6100 | `--carl-surface` #ffffff | Confidence: approximate | 5.54:1 | 4.5:1 | pass |
| `--carl-generic` #5c635d | `--carl-surface` #ffffff | Confidence: traditional | 6.18:1 | 4.5:1 | pass |
| `--carl-accent` #7a5a1f | `--carl-surface` #ffffff | Focus ring on a card | 6.34:1 | 3.0:1 | pass |
| `--carl-accent` #7a5a1f | `--carl-bg` #f6f6f3 | Focus ring on the page | 5.86:1 | 3.0:1 | pass |
| `--carl-border-strong` #b4b4aa | `--carl-surface` #ffffff | **Input / select / textarea border** | 2.09:1 | 3.0:1 | **FAIL** |
| `--carl-border` #d6d6cf | `--carl-surface` #ffffff | Card border, table rule (decorative) | 1.46:1 | 3.0:1 | _advisory_ |

## What "advisory" means

`--carl-border` is decorative: card edges, table rules, the timeline spine.
WCAG 2.1 SC 1.4.11 does not require 3:1 for a purely decorative boundary, and
forcing it there makes every card on a dense screen shout. The validator
reports it but does not block on it.

`--carl-border-strong` is different. It is the visual boundary of every text
input, select and textarea, which SC 1.4.11 *does* cover — so if it reads
**FAIL** above, that is a real defect and the palette should fix it.

## Notes on the method

- Ratios use `(L1 + 0.05) / (L2 + 0.05)` with sRGB relative luminance.
- 4.5:1 is AA for normal text; 3:1 is AA for UI components and large text.
- Carl is used outdoors in direct sun, so treat AA as the floor rather than the
  goal. The placeholder mostly sits between 5:1 and 9:1 and that has worked well
  in the field.
- Chart data series (if you add `--carl-chart-*`) are measured against
  `--carl-surface` at 3:1, and additionally need to be distinguishable **from
  each other** under deuteranopia and protanopia — which contrast arithmetic
  does not test. Check that separately.
